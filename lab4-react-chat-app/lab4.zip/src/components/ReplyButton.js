import React, { Component } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMessage } from '@fortawesome/free-solid-svg-icons';

import './ReplyButton.css';

class ReplyButton extends Component {
    handleSubmit(event) {
        event.preventDefault();
    }

    render() {
        return (
            <button onClick={this.handleSubmit} className="btn reply-button"><FontAwesomeIcon icon={faMessage}/> Reply</button>
        )
    }
}

export default ReplyButton;