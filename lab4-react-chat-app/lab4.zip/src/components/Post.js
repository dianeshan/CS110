import React, { Component } from 'react';

import Voter from './Voter';
import ReplyButton from './ReplyButton';
import './Post.css';

class Post extends Component {

    render() {
        const { user, posttext } = this.props.attrs
        return (
            <div className="container pt-3 centered">
                <div className="w-50">
                    <div>
                        <div className="user">{user}</div>
                        <div className="posttext">
                            {posttext}
                            <span><Voter /></span>
                        </div>
                        <ReplyButton />
                    </div>
                </div>
            </div>
        )
    }
}

export default Post;